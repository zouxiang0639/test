<?php

namespace App\Library\Admin\Consts;

class StyleTypeConst
{
    const FILE = 'file';
    const CODE = 'code';
}
