<link rel="stylesheet" href="{{  assets_path("/lib/AdminLTE/bootstrap/css/bootstrap.min.css") }}">
<!-- Font Awesome -->
<link rel="stylesheet" href="{{  assets_path("/lib/font-awesome/css/font-awesome.min.css") }}">

<!-- Theme style -->
<link rel="stylesheet" href="{{  assets_path("/lib/AdminLTE/dist/css/skins/" . config('admin.skin') .".min.css") }}">
<link rel="stylesheet" href="{{  assets_path("/admin/css/admin.css") }}">

{{--<link rel="stylesheet" href="{{  assets_path("/lib/nprogress/nprogress.css") }}">--}}
<link rel="stylesheet" href="{{  assets_path("/lib/sweetalert/dist/sweetalert.css") }}">

{{--<link rel="stylesheet" href="{{  assets_path("/lib/toastr/build/toastr.min.css") }}">--}}
{{--<link rel="stylesheet" href="{{  assets_path("/lib/bootstrap3-editable/css/bootstrap-editable.css") }}">--}}
{{--<link rel="stylesheet" href="{{  assets_path("/lib/google-fonts/fonts.css") }}">--}}
<link rel="stylesheet" href="{{  assets_path("/lib/AdminLTE/dist/css/AdminLTE.min.css") }}">

<!-- REQUIRED JS SCRIPTS -->
<script src="{{  assets_path("/lib/AdminLTE/plugins/jQuery/jQuery-2.1.4.min.js") }}"></script>
<script src="{{  assets_path("/lib/AdminLTE/bootstrap/js/bootstrap.min.js") }}"></script>
{{--<script src="{{  assets_path("/lib/AdminLTE/plugins/slimScroll/jquery.slimscroll.min.js") }}"></script>--}}
<script src="{{  assets_path("/lib/AdminLTE/dist/js/app.min.js") }}"></script>
{{--<script src="{{  assets_path("/lib/jquery-pjax/jquery.pjax.js") }}"></script>--}}
{{--<script src="{{  assets_path("/lib/nprogress/nprogress.js") }}"></script>--}}


<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
<![endif]-->