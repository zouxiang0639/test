<?php

namespace App\Admin\Bls\System\Model;

use Illuminate\Database\Eloquent\Model;

/**
 * Created by ConfigModel.
 * @author: zouxiang
 * @date:
 */
class ConfigModel extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'admin_config';

}
