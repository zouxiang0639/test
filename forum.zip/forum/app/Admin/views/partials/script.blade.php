
<!-- REQUIRED JS SCRIPTS -->
{{--<script src="{{  assets_path("/lib/toastr/build/toastr.min.js") }}"></script>--}}
{{--<script src="{{  assets_path("/lib/bootstrap3-editable/js/bootstrap-editable.min.js") }}"></script>--}}
<script src="{{  assets_path("/lib/sweetalert/dist/sweetalert.min.js") }}"></script>
<script src="{{  assets_path("/admin/js/admin.js") }}"></script>