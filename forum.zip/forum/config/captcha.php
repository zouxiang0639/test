<?php
return [
    'default'   => [
        'length'    => 5,
        'width'     => 120,
        'height'    => 32,
        'quality'   => 90,
    ],
];