<?php

namespace App\Admin\Bls\Contents\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * Created by TagsModel.
 * @author: zouxiang
 * @date:
 */
class NoticeModel extends Model
{

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'notice';


}
