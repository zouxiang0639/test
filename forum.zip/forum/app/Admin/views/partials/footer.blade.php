<!-- Main Footer -->
<footer class="main-footer">
    <!-- To the right -->
    <strong>版本</strong>&nbsp;&nbsp; {!! config('admin.version') !!}
</footer>