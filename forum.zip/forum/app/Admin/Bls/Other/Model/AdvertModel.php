<?php

namespace App\Admin\Bls\Other\Model;

use Illuminate\Database\Eloquent\Model;

class AdvertModel extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'admin_advert';

}
