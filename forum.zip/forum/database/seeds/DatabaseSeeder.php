<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
         $this->call([
             //TestDataSeeder::class,
             AdminAuthSeeder::class,
             ForumTagsSeeder::class,
             AdminConfigSeeder::class,
             TestSeeder::class,
             FragmentSeeder::class
         ]);
    }
}
